def my_cool_test_method():
    print('It works!')
